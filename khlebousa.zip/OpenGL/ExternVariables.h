#pragma once
extern const int WINDOW_HEIGHT;
extern const int WINDOW_WIDTH;